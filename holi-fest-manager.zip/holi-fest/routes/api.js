const router = require('express').Router();
const crypto = require('crypto');
const { Event, Registration, Vendor, Volunteer, Expense, Setting } = require('../models');

const wrap = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const pick = (obj, keys) =>
  Object.fromEntries(keys.filter(k => obj[k] !== undefined).map(k => [k, obj[k]]));

// Generic CRUD with an allow-list of writable fields (no mass assignment)
function crud(name, Model, allowed, { populate = '', sort = '-createdAt', onDelete } = {}) {
  router.get(`/${name}`, wrap(async (req, res) => {
    const q = Model.find();
    if (populate) q.populate(populate);
    res.json(await q.sort(sort));
  }));

  router.post(`/${name}`, wrap(async (req, res) => {
    res.status(201).json(await Model.create(pick(req.body, allowed)));
  }));

  router.put(`/${name}/:id`, wrap(async (req, res) => {
    const doc = await Model.findById(req.params.id);
    if (!doc) return res.status(404).json({ error: 'Not found' });
    doc.set(pick(req.body, allowed));
    await doc.save();
    res.json(doc);
  }));

  router.delete(`/${name}/:id`, wrap(async (req, res) => {
    const doc = await Model.findByIdAndDelete(req.params.id);
    if (!doc) return res.status(404).json({ error: 'Not found' });
    if (onDelete) await onDelete(doc);
    res.json({ ok: true });
  }));
}

crud('events', Event,
  ['name', 'type', 'date', 'startTime', 'venue', 'capacity', 'price', 'status', 'description'],
  {
    sort: 'date',
    onDelete: async ev => {
      await Registration.deleteMany({ event: ev._id });
      await Volunteer.updateMany({ event: ev._id }, { event: null });
    }
  });

crud('vendors', Vendor, ['name', 'category', 'phone', 'stallNo', 'fee', 'paid']);
crud('volunteers', Volunteer, ['name', 'phone', 'role', 'event', 'shift'], { populate: 'event', sort: 'name' });
crud('expenses', Expense, ['title', 'category', 'amount', 'date', 'paidTo'], { sort: '-date' });

// ---- Ticket bookings -------------------------------------------------------
router.get('/registrations', wrap(async (req, res) => {
  res.json(await Registration.find().populate('event', 'name date startTime').sort('-createdAt'));
}));

router.post('/registrations', wrap(async (req, res) => {
  const { event, name, phone, email, paymentMode } = req.body;
  const tickets = Math.max(1, parseInt(req.body.tickets, 10) || 1);

  // Atomic seat reservation: only succeeds if enough seats remain (no overbooking)
  const ev = await Event.findOneAndUpdate(
    {
      _id: event,
      status: { $in: ['planned', 'live'] },
      $expr: { $lte: [{ $add: ['$registered', tickets] }, '$capacity'] }
    },
    { $inc: { registered: tickets } },
    { new: true }
  );

  if (!ev) {
    const exists = await Event.findById(event);
    if (!exists) return res.status(404).json({ error: 'Event not found' });
    return res.status(409).json({ error: 'Not enough seats left, or bookings are closed for this event' });
  }

  try {
    let reg;
    for (let attempt = 0; attempt < 5 && !reg; attempt++) {
      const code = 'HOLI-' + crypto.randomBytes(3).toString('hex').toUpperCase();
      try {
        reg = await Registration.create({
          event: ev._id, code, name, phone, email, tickets,
          amountPaid: ev.price * tickets,
          paymentMode: ev.price === 0 ? 'free' : (paymentMode || 'upi')
        });
      } catch (e) {
        if (e.code !== 11000) throw e; // retry only on duplicate code
      }
    }
    if (!reg) throw new Error('Could not generate a ticket code');
    res.status(201).json(reg);
  } catch (e) {
    await Event.updateOne({ _id: ev._id }, { $inc: { registered: -tickets } }); // release seats
    throw e;
  }
}));

router.delete('/registrations/:id', wrap(async (req, res) => {
  const reg = await Registration.findByIdAndDelete(req.params.id);
  if (!reg) return res.status(404).json({ error: 'Not found' });
  await Event.updateOne({ _id: reg.event }, { $inc: { registered: -reg.tickets } });
  res.json({ ok: true });
}));

router.post('/checkin', wrap(async (req, res) => {
  const code = String(req.body.code || '').trim().toUpperCase();
  const reg = await Registration.findOneAndUpdate(
    { code, checkedIn: false },
    { checkedIn: true, checkedInAt: new Date() },
    { new: true }
  ).populate('event', 'name');
  if (reg) return res.json(reg);
  const existing = await Registration.findOne({ code });
  if (!existing) return res.status(404).json({ error: `No ticket found for ${code || 'that code'}` });
  res.status(409).json({ error: `${code} was already checked in` });
}));

// ---- Budget and dashboard --------------------------------------------------
router.put('/budget', wrap(async (req, res) => {
  const amount = Number(req.body.amount);
  if (!Number.isFinite(amount) || amount < 0) return res.status(400).json({ error: 'Enter a valid budget amount' });
  await Setting.findOneAndUpdate({ key: 'budget' }, { value: amount }, { upsert: true });
  res.json({ amount });
}));

router.get('/stats', wrap(async (req, res) => {
  const [events, reg, checked, vendors, spent, byCat, budgetDoc] = await Promise.all([
    Event.find().sort('date').lean(),
    Registration.aggregate([{ $group: { _id: null, tickets: { $sum: '$tickets' }, bookings: { $sum: 1 }, revenue: { $sum: '$amountPaid' } } }]),
    Registration.aggregate([{ $match: { checkedIn: true } }, { $group: { _id: null, tickets: { $sum: '$tickets' } } }]),
    Vendor.aggregate([{ $group: { _id: '$paid', total: { $sum: '$fee' } } }]),
    Expense.aggregate([{ $group: { _id: null, total: { $sum: '$amount' } } }]),
    Expense.aggregate([{ $group: { _id: '$category', total: { $sum: '$amount' } } }, { $sort: { total: -1 } }]),
    Setting.findOne({ key: 'budget' }).lean()
  ]);

  const revenue = reg[0]?.revenue || 0;
  const vendorPaid = vendors.find(v => v._id === true)?.total || 0;
  const vendorDue = vendors.find(v => v._id === false)?.total || 0;
  const expenses = spent[0]?.total || 0;

  res.json({
    tickets: reg[0]?.tickets || 0,
    bookings: reg[0]?.bookings || 0,
    capacity: events.filter(e => e.status !== 'cancelled').reduce((s, e) => s + e.capacity, 0),
    checkedIn: checked[0]?.tickets || 0,
    revenue, vendorPaid, vendorDue, expenses,
    budget: budgetDoc?.value || 0,
    net: revenue + vendorPaid - expenses,
    perEvent: events.map(e => ({ name: e.name, type: e.type, registered: e.registered, capacity: e.capacity })),
    expenseByCategory: byCat.map(c => ({ category: c._id, total: c.total }))
  });
}));

module.exports = router;
