// Loads sample Holi data. WARNING: clears existing data in the database.
require('dotenv').config();
const mongoose = require('mongoose');
const { Event, Registration, Vendor, Volunteer, Expense, Setting } = require('./models');

const HOLIKA = new Date('2027-03-21'); // adjust to the actual festival dates
const RANG = new Date('2027-03-22');

(async () => {
  await mongoose.connect(process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/holi_fest');
  await Promise.all([Event, Registration, Vendor, Volunteer, Expense, Setting].map(m => m.deleteMany({})));

  const [dahan, rang, dj, food, kids] = await Event.create([
    { name: 'Holika Dahan', type: 'ritual', date: HOLIKA, startTime: '19:30', venue: 'Main Ground', capacity: 500, price: 0, status: 'planned', description: 'Bonfire and puja with the community.' },
    { name: 'Rang Barse Morning Play', type: 'color-play', date: RANG, startTime: '10:00', venue: 'Main Ground', capacity: 800, price: 299, status: 'planned', description: 'Organic gulal, rain dance and water guns.' },
    { name: 'Dhol and DJ Dance Floor', type: 'music', date: RANG, startTime: '12:00', venue: 'Rain Dance Arena', capacity: 600, price: 199, status: 'planned' },
    { name: 'Thandai and Gujiya Fair', type: 'food', date: RANG, startTime: '11:00', venue: 'Food Court', capacity: 400, price: 0, status: 'planned' },
    { name: 'Kids Pichkari Zone', type: 'kids', date: RANG, startTime: '10:30', venue: 'Lawn B', capacity: 150, price: 149, status: 'planned' }
  ]);

  const bookings = [
    [rang, 'Aarav Sharma', '9876543210', 4], [rang, 'Priya Meena', '9812345678', 2],
    [dj, 'Rohit Singh', '9988776655', 3], [kids, 'Neha Joshi', '9123456780', 2],
    [dahan, 'Karan Gupta', '9001122334', 5]
  ];
  let n = 1000;
  for (const [ev, name, phone, tickets] of bookings) {
    await Registration.create({
      event: ev._id, code: 'HOLI-' + (n++).toString(16).toUpperCase().padStart(6, '0'),
      name, phone, tickets, amountPaid: ev.price * tickets,
      paymentMode: ev.price ? 'upi' : 'free'
    });
    await Event.updateOne({ _id: ev._id }, { $inc: { registered: tickets } });
  }

  await Vendor.create([
    { name: 'Sharma Thandai House', category: 'food', phone: '9811111111', stallNo: 'F1', fee: 8000, paid: true },
    { name: 'Eco Gulal Co.', category: 'colors', phone: '9822222222', stallNo: 'C1', fee: 5000, paid: true },
    { name: 'Dhol Beats Sound', category: 'sound', phone: '9833333333', stallNo: 'S1', fee: 0, paid: false },
    { name: 'Jaipur Chaat Corner', category: 'food', phone: '9844444444', stallNo: 'F2', fee: 6000, paid: false }
  ]);

  await Volunteer.create([
    { name: 'Manish Verma', phone: '9855555555', role: 'entry-desk', event: rang._id, shift: '8:00 to 12:00' },
    { name: 'Sonal Rathore', phone: '9866666666', role: 'water-safety', event: rang._id, shift: '9:00 to 14:00' },
    { name: 'Deepak Yadav', phone: '9877777777', role: 'color-station', event: rang._id, shift: '9:00 to 13:00' },
    { name: 'Anjali Saini', phone: '9888888888', role: 'first-aid', event: null, shift: 'Full day' }
  ]);

  await Expense.create([
    { title: 'Organic gulal (200 kg)', category: 'colors', amount: 24000, paidTo: 'Eco Gulal Co.', date: new Date('2027-03-10') },
    { title: 'Water tankers', category: 'water', amount: 9000, paidTo: 'City Water Supply', date: new Date('2027-03-15') },
    { title: 'Sound and stage', category: 'sound', amount: 35000, paidTo: 'Dhol Beats Sound', date: new Date('2027-03-12') },
    { title: 'Event permit', category: 'permits', amount: 5000, paidTo: 'Municipal Office', date: new Date('2027-03-01') }
  ]);

  await Setting.create({ key: 'budget', value: 120000 });

  console.log('Sample Holi data loaded.');
  await mongoose.disconnect();
})().catch(e => { console.error(e); process.exit(1); });
