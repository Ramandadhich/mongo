const mongoose = require('mongoose');
const { Schema } = mongoose;
const opts = { timestamps: true };

const eventSchema = new Schema({
  name: { type: String, required: [true, 'Event name is required'], trim: true },
  type: { type: String, enum: ['ritual', 'color-play', 'music', 'food', 'kids', 'other'], default: 'color-play' },
  date: { type: Date, required: [true, 'Date is required'] },
  startTime: { type: String, default: '10:00' },
  venue: { type: String, required: [true, 'Venue is required'], trim: true },
  capacity: { type: Number, required: [true, 'Capacity is required'], min: [1, 'Capacity must be at least 1'] },
  price: { type: Number, default: 0, min: 0 },
  registered: { type: Number, default: 0, min: 0 },
  status: { type: String, enum: ['planned', 'live', 'done', 'cancelled'], default: 'planned' },
  description: { type: String, trim: true }
}, opts);

eventSchema.pre('validate', function (next) {
  if (this.capacity < this.registered) {
    this.invalidate('capacity', `Capacity cannot be below the ${this.registered} seats already booked`);
  }
  next();
});

const registrationSchema = new Schema({
  event: { type: Schema.Types.ObjectId, ref: 'Event', required: true, index: true },
  code: { type: String, unique: true, required: true },
  name: { type: String, required: [true, 'Name is required'], trim: true },
  phone: { type: String, required: [true, 'Phone is required'], match: [/^[0-9+\-\s]{7,15}$/, 'Enter a valid phone number'] },
  email: { type: String, trim: true, lowercase: true },
  tickets: { type: Number, default: 1, min: [1, 'Book at least 1 ticket'], max: [20, 'Maximum 20 tickets per booking'] },
  amountPaid: { type: Number, default: 0, min: 0 },
  paymentMode: { type: String, enum: ['cash', 'upi', 'card', 'free'], default: 'upi' },
  checkedIn: { type: Boolean, default: false },
  checkedInAt: Date
}, opts);

const vendorSchema = new Schema({
  name: { type: String, required: [true, 'Vendor name is required'], trim: true },
  category: { type: String, enum: ['food', 'colors', 'music', 'sound', 'security', 'other'], default: 'food' },
  phone: { type: String, trim: true },
  stallNo: { type: String, trim: true },
  fee: { type: Number, default: 0, min: 0 },
  paid: { type: Boolean, default: false }
}, opts);

const volunteerSchema = new Schema({
  name: { type: String, required: [true, 'Volunteer name is required'], trim: true },
  phone: { type: String, trim: true },
  role: { type: String, enum: ['entry-desk', 'color-station', 'water-safety', 'food', 'stage', 'first-aid', 'cleanup'], default: 'entry-desk' },
  event: { type: Schema.Types.ObjectId, ref: 'Event', default: null },
  shift: { type: String, trim: true }
}, opts);

const expenseSchema = new Schema({
  title: { type: String, required: [true, 'Expense title is required'], trim: true },
  category: { type: String, enum: ['colors', 'water', 'food', 'sound', 'decor', 'permits', 'staff', 'other'], default: 'other' },
  amount: { type: Number, required: [true, 'Amount is required'], min: [0, 'Amount cannot be negative'] },
  date: { type: Date, default: Date.now },
  paidTo: { type: String, trim: true }
}, opts);

const settingSchema = new Schema({
  key: { type: String, unique: true, required: true },
  value: Schema.Types.Mixed
});

module.exports = {
  Event: mongoose.model('Event', eventSchema),
  Registration: mongoose.model('Registration', registrationSchema),
  Vendor: mongoose.model('Vendor', vendorSchema),
  Volunteer: mongoose.model('Volunteer', volunteerSchema),
  Expense: mongoose.model('Expense', expenseSchema),
  Setting: mongoose.model('Setting', settingSchema)
};
