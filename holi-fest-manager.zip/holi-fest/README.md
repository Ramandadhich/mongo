# Holi Fest Desk

Festival event management system for a Holi celebration. Built with Node.js, Express and MongoDB (Mongoose), with a single-page admin interface.

## Features
- **Events**: Holika Dahan, colour play, music, food fair, kids zone, each with date, venue, capacity and price
- **Tickets**: book seats with a unique code such as `HOLI-A1B2C3`; seats are reserved atomically, so an event can never be overbooked
- **Gate check-in**: type or scan a ticket code; a code cannot be checked in twice
- **Vendors**: stalls, fees and whether the fee has been received
- **Volunteers**: roles, shifts and event assignment
- **Expenses and budget**: spending by category against a total budget
- **Dashboard**: tickets sold, attendance, revenue, vendor fees, spend, net balance

## Setup
1. Install Node.js 18+ and MongoDB (local) or create a free MongoDB Atlas cluster.
2. In this folder:
   ```bash
   npm install
   cp .env.example .env     # edit MONGODB_URI if you use Atlas
   npm run seed             # optional: loads sample Holi data (clears existing data)
   npm start
   ```
3. Open http://localhost:3000

## REST API
| Method | Path | Purpose |
|---|---|---|
| GET/POST | `/api/events` | List or create events |
| PUT/DELETE | `/api/events/:id` | Update or delete (also deletes its tickets) |
| GET/POST | `/api/registrations` | List tickets or book seats (`event, name, phone, tickets`) |
| DELETE | `/api/registrations/:id` | Cancel a booking and release its seats |
| POST | `/api/checkin` | `{ "code": "HOLI-XXXXXX" }` |
| GET/POST, PUT/DELETE | `/api/vendors`, `/api/volunteers`, `/api/expenses` | Standard CRUD |
| PUT | `/api/budget` | `{ "amount": 120000 }` |
| GET | `/api/stats` | Dashboard totals |

## Project layout
```
server.js          Express app and MongoDB connection
models/index.js    Mongoose schemas
routes/api.js      API routes and booking logic
seed.js            Sample data
public/index.html  Admin interface
```

## Notes
- There is no login. Run it on a trusted network, or add authentication before exposing it to the internet.
- The sample dates in `seed.js` are placeholders; change them to the real Holi dates.
