import datetime
from functools import wraps

import bcrypt
import jwt
from flask import Blueprint, request, jsonify, current_app, g

from config import Config
from db import users_col

auth_bp = Blueprint("auth", __name__, url_prefix="/api/auth")

VALID_ROLES = {"admin", "analyst"}


def hash_password(plain_password: str) -> bytes:
    return bcrypt.hashpw(plain_password.encode("utf-8"), bcrypt.gensalt())


def verify_password(plain_password: str, hashed: bytes) -> bool:
    return bcrypt.checkpw(plain_password.encode("utf-8"), hashed)


def generate_token(user: dict) -> str:
    payload = {
        "sub": str(user["_id"]),
        "username": user["username"],
        "role": user["role"],
        "exp": datetime.datetime.utcnow() + datetime.timedelta(minutes=Config.JWT_EXP_MINUTES),
        "iat": datetime.datetime.utcnow(),
    }
    return jwt.encode(payload, Config.JWT_SECRET, algorithm=Config.JWT_ALGORITHM)


def token_required(f):
    """Decorator: validates the JWT from the Authorization header and stores
    the decoded claims on flask.g.current_user."""

    @wraps(f)
    def decorated(*args, **kwargs):
        auth_header = request.headers.get("Authorization", "")
        if not auth_header.startswith("Bearer "):
            return jsonify({"error": "Missing or malformed Authorization header"}), 401

        token = auth_header.split(" ", 1)[1]
        try:
            payload = jwt.decode(token, Config.JWT_SECRET, algorithms=[Config.JWT_ALGORITHM])
        except jwt.ExpiredSignatureError:
            return jsonify({"error": "Token expired"}), 401
        except jwt.InvalidTokenError:
            return jsonify({"error": "Invalid token"}), 401

        g.current_user = payload
        return f(*args, **kwargs)

    return decorated


def roles_required(*allowed_roles):
    """Decorator factory for role-based access control. Use after token_required."""

    def wrapper(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            user_role = g.current_user.get("role")
            if user_role not in allowed_roles:
                return jsonify({"error": "Insufficient permissions"}), 403
            return f(*args, **kwargs)

        return decorated

    return wrapper


@auth_bp.route("/register", methods=["POST"])
def register():
    data = request.get_json(silent=True) or {}
    username = (data.get("username") or "").strip()
    password = data.get("password") or ""
    role = data.get("role", "analyst")

    if not username or not password:
        return jsonify({"error": "username and password are required"}), 400
    if role not in VALID_ROLES:
        return jsonify({"error": f"role must be one of {sorted(VALID_ROLES)}"}), 400
    if len(password) < 8:
        return jsonify({"error": "password must be at least 8 characters"}), 400

    if users_col.find_one({"username": username}):
        return jsonify({"error": "username already exists"}), 409

    user_doc = {
        "username": username,
        "password_hash": hash_password(password),
        "role": role,
        "created_at": datetime.datetime.utcnow(),
    }
    result = users_col.insert_one(user_doc)
    user_doc["_id"] = result.inserted_id

    token = generate_token(user_doc)
    return jsonify({"message": "user registered", "token": token, "role": role}), 201


@auth_bp.route("/login", methods=["POST"])
def login():
    data = request.get_json(silent=True) or {}
    username = (data.get("username") or "").strip()
    password = data.get("password") or ""

    user = users_col.find_one({"username": username})
    if not user or not verify_password(password, user["password_hash"]):
        return jsonify({"error": "invalid credentials"}), 401

    token = generate_token(user)
    return jsonify({"message": "login successful", "token": token, "role": user["role"]}), 200
