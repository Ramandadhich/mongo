# SentinelLog — Security Log Aggregation & Threat Detection System

A MongoDB-backed security monitoring platform: ingest security events (failed
logins, port probes, etc.), automatically detect attack patterns like
brute-force login attempts and port scans, and view everything on a live
dashboard.

## Tech Stack
- **Database:** MongoDB (aggregation pipelines, indexes, TTL-friendly design)
- **Backend:** Python, Flask, PyMongo
- **Auth:** JWT + bcrypt password hashing, role-based access control (admin / analyst)
- **Frontend:** Server-rendered HTML + vanilla JS + Chart.js (no build step needed)

## Why this project demonstrates MongoDB well
- **Schema-flexible log documents** — different event types (`failed_login`,
  `port_probe`, `file_access`, …) carry different optional fields, which
  MongoDB's document model handles naturally without a rigid schema.
- **Aggregation framework** — `threat_detection.py` and the `/api/stats`
  endpoint use `$match`, `$group`, `$count`, and `$sort` pipelines to detect
  attack patterns and power dashboard analytics in real time.
- **Indexing strategy** — compound and single-field indexes on `source_ip`,
  `timestamp`, and `event_type` keep detection queries fast as log volume grows.
- **Three collections, one coherent system** — `users`, `logs`, `alerts`
  show one-to-many relationships (one IP → many logs → triggered alerts)
  modeled with references rather than joins.

## Project Structure
```
sentinellog/
├── app.py                 # Flask app entry point + page routes
├── config.py               # Environment-based configuration
├── db.py                   # MongoDB connection + index setup
├── auth.py                 # Register/login, JWT, RBAC decorators
├── logs.py                 # Log ingestion, querying, alerts, stats API
├── threat_detection.py     # Rule-based detection engine (aggregation pipelines)
├── seed_data.py             # Populates demo users + realistic attack traffic
├── requirements.txt
├── .env.example
├── templates/
│   ├── login.html
│   └── dashboard.html
└── static/css/style.css
```

## Setup

1. **Install MongoDB** locally (Community Edition) or use a free
   [MongoDB Atlas](https://www.mongodb.com/cloud/atlas) cluster and copy its
   connection string.

2. **Install dependencies:**
   ```bash
   pip install -r requirements.txt
   ```

3. **Configure environment:**
   ```bash
   cp .env.example .env
   # edit .env — set MONGO_URI (and JWT_SECRET to any long random string)
   ```

4. **Seed demo data** (creates an admin account and simulates a brute-force
   attack + port scan so the dashboard has something to show immediately):
   ```bash
   python seed_data.py
   ```

5. **Run the app:**
   ```bash
   python app.py
   ```
   Visit `http://localhost:5000`, log in with `admin` / `Admin@12345`.

## How the detection engine works
Every time a log is ingested via `POST /api/logs`, `threat_detection.py` runs
the rule relevant to that event type:

- **Brute-force rule:** counts `failed_login` events from the same
  `source_ip` in the last `FAILED_LOGIN_WINDOW_MINUTES` (default 10). If it
  crosses `FAILED_LOGIN_THRESHOLD` (default 5), a `high` severity alert fires.
- **Port-scan rule:** counts *distinct* destination ports probed by one
  `source_ip` in the last `PORT_SCAN_WINDOW_MINUTES` (default 5) using a
  `$group` aggregation. If it crosses `PORT_SCAN_UNIQUE_PORT_THRESHOLD`
  (default 15), a `medium` severity alert fires.
- Alerts are deduplicated with a 15-minute cooldown per `(source_ip, rule)`
  pair so one ongoing attack doesn't spam duplicate alerts.

Both thresholds are configurable via `.env`, and the pattern is designed so
adding a new rule is just a new function in `threat_detection.py`.

## API Reference
| Method | Endpoint | Auth | Description |
|---|---|---|---|
| POST | `/api/auth/register` | — | Create a user (`role`: `admin` or `analyst`) |
| POST | `/api/auth/login` | — | Get a JWT |
| POST | `/api/logs` | JWT | Ingest a security event |
| GET | `/api/logs` | JWT | List logs (filter by `source_ip`, `event_type`) |
| GET | `/api/alerts` | JWT | List alerts (filter by `severity`, `status`) |
| PATCH | `/api/alerts/<id>/resolve` | JWT, admin only | Mark an alert resolved |
| GET | `/api/stats` | JWT | Dashboard aggregation stats |

## Possible extensions (good viva talking points)
- Feed in real logs from Wireshark/Nmap output you've already generated in
  your pentesting labs, parsed into the same event schema.
- Add a `geoip` field and flag alerts from unexpected countries.
- Add MongoDB Change Streams to push alerts to the dashboard via WebSocket
  instead of polling every 15 seconds.
- Add a TTL index on `logs.timestamp` to auto-expire old logs after N days.
