"""
Lightweight rule-based threat detection engine.

Each rule queries recent documents in the `logs` collection using MongoDB's
aggregation framework and, if a threshold is crossed, writes a document into
the `alerts` collection (deduplicated per source_ip + rule within a cooldown
window so the same activity doesn't spam duplicate alerts).
"""
import datetime

from config import Config
from db import logs_col, alerts_col

ALERT_COOLDOWN_MINUTES = 15


def _recent_alert_exists(source_ip: str, rule: str) -> bool:
    cutoff = datetime.datetime.utcnow() - datetime.timedelta(minutes=ALERT_COOLDOWN_MINUTES)
    return alerts_col.find_one({
        "source_ip": source_ip,
        "rule": rule,
        "timestamp": {"$gte": cutoff},
    }) is not None


def _raise_alert(source_ip: str, rule: str, severity: str, description: str, evidence: dict):
    if _recent_alert_exists(source_ip, rule):
        return None

    alert = {
        "source_ip": source_ip,
        "rule": rule,
        "severity": severity,
        "description": description,
        "evidence": evidence,
        "timestamp": datetime.datetime.utcnow(),
        "status": "open",
    }
    result = alerts_col.insert_one(alert)
    alert["_id"] = result.inserted_id
    return alert


def check_brute_force(source_ip: str):
    """Rule: too many failed_login events from one IP within a time window."""
    window_start = datetime.datetime.utcnow() - datetime.timedelta(
        minutes=Config.FAILED_LOGIN_WINDOW_MINUTES
    )

    count = logs_col.count_documents({
        "source_ip": source_ip,
        "event_type": "failed_login",
        "timestamp": {"$gte": window_start},
    })

    if count >= Config.FAILED_LOGIN_THRESHOLD:
        return _raise_alert(
            source_ip=source_ip,
            rule="brute_force_login",
            severity="high",
            description=(
                f"{count} failed login attempts from {source_ip} in the last "
                f"{Config.FAILED_LOGIN_WINDOW_MINUTES} minutes"
            ),
            evidence={"failed_attempts": count, "window_minutes": Config.FAILED_LOGIN_WINDOW_MINUTES},
        )
    return None


def check_port_scan(source_ip: str):
    """Rule: one IP touching many distinct destination ports quickly = scan pattern."""
    window_start = datetime.datetime.utcnow() - datetime.timedelta(
        minutes=Config.PORT_SCAN_WINDOW_MINUTES
    )

    pipeline = [
        {"$match": {
            "source_ip": source_ip,
            "event_type": "port_probe",
            "timestamp": {"$gte": window_start},
        }},
        {"$group": {"_id": "$dest_port"}},
        {"$count": "unique_ports"},
    ]
    result = list(logs_col.aggregate(pipeline))
    unique_ports = result[0]["unique_ports"] if result else 0

    if unique_ports >= Config.PORT_SCAN_UNIQUE_PORT_THRESHOLD:
        return _raise_alert(
            source_ip=source_ip,
            rule="port_scan",
            severity="medium",
            description=(
                f"{source_ip} probed {unique_ports} distinct ports in the last "
                f"{Config.PORT_SCAN_WINDOW_MINUTES} minutes"
            ),
            evidence={"unique_ports": unique_ports, "window_minutes": Config.PORT_SCAN_WINDOW_MINUTES},
        )
    return None


def run_detection_for_log(log_doc: dict):
    """Called right after a log is ingested. Runs the relevant rule(s) for
    that log's event_type against its source_ip."""
    source_ip = log_doc.get("source_ip")
    if not source_ip:
        return []

    triggered = []
    if log_doc.get("event_type") == "failed_login":
        alert = check_brute_force(source_ip)
        if alert:
            triggered.append(alert)

    if log_doc.get("event_type") == "port_probe":
        alert = check_port_scan(source_ip)
        if alert:
            triggered.append(alert)

    return triggered
