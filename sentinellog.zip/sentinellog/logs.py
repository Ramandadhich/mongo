import datetime

from bson import ObjectId
from flask import Blueprint, request, jsonify, g

from auth import token_required, roles_required
from db import logs_col, alerts_col
from threat_detection import run_detection_for_log

logs_bp = Blueprint("logs", __name__, url_prefix="/api")

VALID_EVENT_TYPES = {"failed_login", "successful_login", "port_probe", "file_access", "malware_signature"}


def serialize(doc: dict) -> dict:
    doc = dict(doc)
    doc["_id"] = str(doc["_id"])
    for key in ("timestamp",):
        if key in doc and isinstance(doc[key], datetime.datetime):
            doc[key] = doc[key].isoformat() + "Z"
    return doc


@logs_bp.route("/logs", methods=["POST"])
@token_required
def ingest_log():
    """Accepts a single security event, e.g.:
    {
      "source_ip": "10.0.0.5",
      "event_type": "failed_login",
      "username": "admin",
      "dest_port": 22,
      "message": "SSH auth failure"
    }
    """
    data = request.get_json(silent=True) or {}
    event_type = data.get("event_type")
    source_ip = data.get("source_ip")

    if not source_ip or event_type not in VALID_EVENT_TYPES:
        return jsonify({
            "error": "source_ip is required and event_type must be one of "
                      f"{sorted(VALID_EVENT_TYPES)}"
        }), 400

    log_doc = {
        "source_ip": source_ip,
        "event_type": event_type,
        "username": data.get("username"),
        "dest_port": data.get("dest_port"),
        "message": data.get("message", ""),
        "ingested_by": g.current_user["username"],
        "timestamp": datetime.datetime.utcnow(),
    }
    result = logs_col.insert_one(log_doc)
    log_doc["_id"] = result.inserted_id

    triggered_alerts = run_detection_for_log(log_doc)

    return jsonify({
        "message": "log ingested",
        "log": serialize(log_doc),
        "alerts_triggered": [serialize(a) for a in triggered_alerts],
    }), 201


@logs_bp.route("/logs", methods=["GET"])
@token_required
def list_logs():
    query = {}
    if request.args.get("source_ip"):
        query["source_ip"] = request.args["source_ip"]
    if request.args.get("event_type"):
        query["event_type"] = request.args["event_type"]

    limit = min(int(request.args.get("limit", 50)), 200)
    skip = int(request.args.get("skip", 0))

    cursor = logs_col.find(query).sort("timestamp", -1).skip(skip).limit(limit)
    return jsonify({"logs": [serialize(d) for d in cursor], "count": logs_col.count_documents(query)})


@logs_bp.route("/alerts", methods=["GET"])
@token_required
def list_alerts():
    query = {}
    if request.args.get("severity"):
        query["severity"] = request.args["severity"]
    if request.args.get("status"):
        query["status"] = request.args["status"]

    cursor = alerts_col.find(query).sort("timestamp", -1).limit(100)
    return jsonify({"alerts": [serialize(d) for d in cursor]})


@logs_bp.route("/alerts/<alert_id>/resolve", methods=["PATCH"])
@token_required
@roles_required("admin")
def resolve_alert(alert_id):
    result = alerts_col.update_one(
        {"_id": ObjectId(alert_id)},
        {"$set": {"status": "resolved", "resolved_by": g.current_user["username"],
                   "resolved_at": datetime.datetime.utcnow()}},
    )
    if result.matched_count == 0:
        return jsonify({"error": "alert not found"}), 404
    return jsonify({"message": "alert resolved"})


@logs_bp.route("/stats", methods=["GET"])
@token_required
def stats():
    """Aggregation-heavy endpoint that powers the dashboard: event counts by
    type, alerts by severity, and the noisiest source IPs."""

    events_by_type = list(logs_col.aggregate([
        {"$group": {"_id": "$event_type", "count": {"$sum": 1}}},
        {"$sort": {"count": -1}},
    ]))

    alerts_by_severity = list(alerts_col.aggregate([
        {"$group": {"_id": "$severity", "count": {"$sum": 1}}},
        {"$sort": {"count": -1}},
    ]))

    top_source_ips = list(logs_col.aggregate([
        {"$group": {"_id": "$source_ip", "count": {"$sum": 1}}},
        {"$sort": {"count": -1}},
        {"$limit": 5},
    ]))

    open_alerts = alerts_col.count_documents({"status": "open"})
    total_logs = logs_col.count_documents({})

    return jsonify({
        "total_logs": total_logs,
        "open_alerts": open_alerts,
        "events_by_type": [{"event_type": r["_id"], "count": r["count"]} for r in events_by_type],
        "alerts_by_severity": [{"severity": r["_id"], "count": r["count"]} for r in alerts_by_severity],
        "top_source_ips": [{"source_ip": r["_id"], "count": r["count"]} for r in top_source_ips],
    })
