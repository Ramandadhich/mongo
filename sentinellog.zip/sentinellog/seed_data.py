"""
Run this after starting MongoDB to populate the database with a demo admin
account and realistic-looking traffic, including a simulated brute-force
login attack and a port-scan, so the threat detection rules have something
to fire on immediately.

Usage:
    python seed_data.py
"""
import datetime
import random

from faker import Faker

from db import users_col, logs_col, alerts_col
from auth import hash_password
from threat_detection import run_detection_for_log

fake = Faker()

EVENT_TYPES_NORMAL = ["successful_login", "file_access"]
COMMON_PORTS = [22, 80, 443, 3306, 8080]


def reset_collections():
    users_col.delete_many({})
    logs_col.delete_many({})
    alerts_col.delete_many({})
    print("Cleared existing users, logs, and alerts.")


def create_demo_users():
    users_col.insert_many([
        {
            "username": "admin",
            "password_hash": hash_password("Admin@12345"),
            "role": "admin",
            "created_at": datetime.datetime.utcnow(),
        },
        {
            "username": "analyst1",
            "password_hash": hash_password("Analyst@123"),
            "role": "analyst",
            "created_at": datetime.datetime.utcnow(),
        },
    ])
    print("Created demo users: admin/Admin@12345, analyst1/Analyst@123")


def insert_log(source_ip, event_type, username=None, dest_port=None, message="", minutes_ago=0):
    doc = {
        "source_ip": source_ip,
        "event_type": event_type,
        "username": username,
        "dest_port": dest_port,
        "message": message,
        "ingested_by": "seed_script",
        "timestamp": datetime.datetime.utcnow() - datetime.timedelta(minutes=minutes_ago),
    }
    logs_col.insert_one(doc)
    return doc


def seed_normal_traffic(n=40):
    for _ in range(n):
        ip = fake.ipv4_public()
        event_type = random.choice(EVENT_TYPES_NORMAL)
        insert_log(
            source_ip=ip,
            event_type=event_type,
            username=fake.user_name(),
            dest_port=random.choice(COMMON_PORTS),
            message=fake.sentence(nb_words=6),
            minutes_ago=random.randint(0, 240),
        )
    print(f"Seeded {n} normal traffic events.")


def seed_brute_force_attack():
    attacker_ip = "185.220.101.7"  # looks like a Tor exit node range, for realism
    for i in range(8):
        insert_log(
            source_ip=attacker_ip,
            event_type="failed_login",
            username="admin",
            message="SSH authentication failure",
            minutes_ago=8 - i,
        )
    print(f"Seeded brute-force attack pattern from {attacker_ip}.")


def seed_port_scan():
    scanner_ip = "45.155.204.19"
    ports = list(range(20, 40))
    for i, port in enumerate(ports):
        insert_log(
            source_ip=scanner_ip,
            event_type="port_probe",
            dest_port=port,
            message="SYN probe",
            minutes_ago=4 - (i * 4 // len(ports)),
        )
    print(f"Seeded port-scan pattern from {scanner_ip} across {len(ports)} ports.")


def run_detection_pass():
    """Re-runs the detection rules over the freshly seeded attack IPs so the
    alerts collection is populated immediately (normally this happens live
    as each log is ingested through the API)."""
    triggered = 0
    for ip in {"185.220.101.7", "45.155.204.19"}:
        for doc in logs_col.find({"source_ip": ip}):
            alerts = run_detection_for_log(doc)
            triggered += len(alerts)
    print(f"Detection pass complete — {triggered} alert(s) raised.")


if __name__ == "__main__":
    reset_collections()
    create_demo_users()
    seed_normal_traffic()
    seed_brute_force_attack()
    seed_port_scan()
    run_detection_pass()
    print("\nSeeding complete. Start the app with: python app.py")
    print("Then log in at http://localhost:5000 with admin / Admin@12345")
