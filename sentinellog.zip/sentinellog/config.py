import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
    DB_NAME = os.getenv("DB_NAME", "sentinellog")

    JWT_SECRET = os.getenv("JWT_SECRET", "dev_secret_change_me")
    JWT_ALGORITHM = "HS256"
    JWT_EXP_MINUTES = int(os.getenv("JWT_EXP_MINUTES", 60))

    FAILED_LOGIN_THRESHOLD = int(os.getenv("FAILED_LOGIN_THRESHOLD", 5))
    FAILED_LOGIN_WINDOW_MINUTES = int(os.getenv("FAILED_LOGIN_WINDOW_MINUTES", 10))

    PORT_SCAN_UNIQUE_PORT_THRESHOLD = int(os.getenv("PORT_SCAN_UNIQUE_PORT_THRESHOLD", 15))
    PORT_SCAN_WINDOW_MINUTES = int(os.getenv("PORT_SCAN_WINDOW_MINUTES", 5))
