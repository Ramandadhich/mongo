from flask import Flask, render_template

from db import init_indexes
from auth import auth_bp
from logs import logs_bp


def create_app():
    app = Flask(__name__)
    app.register_blueprint(auth_bp)
    app.register_blueprint(logs_bp)

    with app.app_context():
        init_indexes()

    @app.route("/")
    def index():
        return render_template("login.html")

    @app.route("/dashboard")
    def dashboard():
        return render_template("dashboard.html")

    return app


app = create_app()

if __name__ == "__main__":
    app.run(debug=True, port=5000)
