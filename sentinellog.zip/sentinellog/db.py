from pymongo import MongoClient, ASCENDING, DESCENDING
from config import Config

_client = MongoClient(Config.MONGO_URI)
db = _client[Config.DB_NAME]

users_col = db["users"]
logs_col = db["logs"]
alerts_col = db["alerts"]


def init_indexes():
    """Create indexes used for auth lookups and threat-detection queries."""
    users_col.create_index([("username", ASCENDING)], unique=True)

    logs_col.create_index([("source_ip", ASCENDING), ("timestamp", DESCENDING)])
    logs_col.create_index([("event_type", ASCENDING)])
    logs_col.create_index([("timestamp", DESCENDING)])

    alerts_col.create_index([("timestamp", DESCENDING)])
    alerts_col.create_index([("severity", ASCENDING)])
    alerts_col.create_index([("source_ip", ASCENDING)])
